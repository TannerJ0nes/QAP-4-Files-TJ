const motel = {
    name: 'Tanner Jones',
    Birthday: new Date('04/16/2002'),
    gender: 'Male',
    pref: ['Early Check-in','Extra Bed', 'Extra Key','late check-out'],
    payment: 'Cash',
    addres: {
        Streetnum:20,
        Streetname: 'Edgecombe Drive',
        city: 'St.Johns',
        province: 'NL',
        postal: 'A1B4P1',
    },
    phonenum: '709-884-3924',
    date: {
    checkin: new Date('03/16/2023'),
    checkout: new Date('03/20/2023'),
},

}


// To Determine How old customer is.
let Birthday;
Birthday = new Date(motel.Birthday)
birthdate = Date.now() - Birthday.getTime();
age_dt = new Date(birthdate);
year = age_dt.getUTCFullYear();
birthage = Math.abs(year - 1970);

//To Determine How long customer is staying at motel
let checkin;
let checkout;
checkin = new Date(motel.date.checkin);
checkout = new Date(motel.date.checkout);
stay = checkout.getTime() - checkin.getTime();
stayyear = new Date(stay);
days = stay/(1000 * 3600 * 24)

//Outputting Formatted html componets to display using text
//and components from object using .notation
html = `
<h1>QAP 4 Java Script</h1>
<p>The guest ${motel.name}, age
${birthage} Will be staying at the Motel
for ${days} days. His room preference is ${motel.pref[3]}. He will pay in 
${motel.payment} Upon his arivial. His address is ${motel.addres.Streetnum} 
${motel.addres.Streetname}. ${motel.addres.city} ${motel.addres.province},
${motel.addres.postal}. For contact purposes his number is ${motel.phonenum}</p>`;

//used to display html above on website when page is ran
document.body.innerHTML = html;